
import './App.css';
import Footer from './Components/footer';
import Testimonial from './Components/testimonial.js';
import About from './Components/about.js';
import Category from './Components/category.js';
import SpearingExperience from './Components/springExprience.js';
import MainContent from './Components/MainContent.js';

function App() {
  return <>
    <MainContent/>
    <SpearingExperience/>
    <Category/>
    <About/>
    <Testimonial/>    
    <Footer/>
  </>
}

export default App;